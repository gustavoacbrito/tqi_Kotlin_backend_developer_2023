package com.TQI.jumarket

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class JumarketApplicationTests {

	@Test
	fun contextLoads() {
	}

}
